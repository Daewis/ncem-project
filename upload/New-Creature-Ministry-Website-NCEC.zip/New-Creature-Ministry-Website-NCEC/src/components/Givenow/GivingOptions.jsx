// import React from 'react'

import { Link } from "react-router-dom"
import GiveIcon from '../../assets/Give_Icon.png'
import PadlockIcon from '../../assets/Padlock_Icon.png'
import BankIcon from '../../assets/Bank_Icon.png'
import AmountButton from "./AmountButton";
import { useState } from "react";
import GivingForm from "./GivingForm";


const GivingOptions = () => {

    const amounts = ["$25", "$50", "$100", "Other"];
    const [checked, setChecked] = useState(false)
    const bankFields = [
        {
            label: "ACCOUNT NAME",
            placeholder: "New Creature Evangelical Ministry"
        },
        {
            label: "BANK NAME",
            placeholder: "First National Bank"
        },
        {
            label: "ACCOUNT NUMBER",
            placeholder: "1234 5678 9012 3456"
        },
        {
            label: "SWIFT/IBAN",
            placeholder: "FNBUS33XXX"
        }
    ]
    return (
        <div className="max-w-7xl mx-auto flex items-center gap-5 py-30 px-5 bg-primary">
            <div className="border border-offwhite p-10 space-y-8.5 rounded-[5px] bg-white">
                <div className="bg-[#E7EEFE] p-5 rounded-xl w-16 h-16">
                    <img src={GiveIcon} alt="" />
                </div>

                <h3 className="font-semibold text-[24px] text-blue">Online Giving</h3>
                <p className="font-normal text-[16px] text-offwhite max-w-[328.67px]">
                    Securely give one-time or set up a
                    recurring gift using a credit card or bank
                    account.
                </p>
                <div className="grid justify-between items-center grid-cols-2 gap-3 text-center">
                    {amounts.map((amount) => (
                        <AmountButton key={amount} amount={amount}
                        />
                    ))}
                </div>
                <div className="flex items-center gap-2">
                    <input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} className="w-4 h-4 cursor-pointer" />
                    <label className="text-[16px] font-normal">Make this a recurring gift</label>
                </div>
                <button className="bg-blue text-white py-3 px-30 font-semibold text-[14px] rounded-2xl cursor-pointer">
                    <Link to='/givenow'>Proceed to Give</Link>
                </button>
                <div className="flex items-center gap-3">
                    <div className="flex justify-center items-center p-2"> <img src={PadlockIcon} alt="" /></div>
                    <p className="text-[12px] font-normal">Secure Encrypted Transaction</p>
                </div>
            </div>
            <div className="border border-offwhite p-10 space-y-5 rounded-[5px] bg-white">
                <div className="w-16 h-16 bg-[#E7EEFE] rounded-1xl p-5">
                    <img src={BankIcon} alt="" />
                </div>

                <h3 className="font-semibold text-[24px] text-blue">Bank Transfer</h3>
                <p className="text-[16px] text-offwhite max-w-[328.67px]">
                    Set up a direct transfer from your bank
                    using the details provided below.
                </p>
                <form action="" className="space-y-3">
                    {bankFields.map((field) => (
                        <GivingForm key={field.label
                        }
                            label={field.label}
                            placeholder={field.placeholder}
                        />
                    ))}


                </form>
            </div>
        </div>
    )
}

export default GivingOptions