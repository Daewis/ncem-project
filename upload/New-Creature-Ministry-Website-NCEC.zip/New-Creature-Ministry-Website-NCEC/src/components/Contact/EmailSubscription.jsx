// import React from 'react'
import AlarmImage from '../../assets/Text.png'

const EmailSubscription = () => {
    return (
        <div className="bg-[#F0F3FF] flex  justify-center items-center p-30 max-w-7xl mx-auto  ">
            <div className="text-center space-y-4 flex justify-center items-center flex-col">
                <img src={AlarmImage} alt="" />
                <h1 className="font-bold text-[48px] text-blue
                ">Stay Connected</h1>
                <p className="text-[18px] text-offwhite">
                    Receive updates about church programs, events and activities.
                </p>
                <div className="flex justify-between items-center gap-5 mt-8">
                    <input type="email" placeholder="Enter your email" className="border border-offwhite py-2 pl-3 pr-25 rounded-2xl" />
                    <button className="bg-yellow px-10 py-2 rounded-2xl text-offwhite font-semibold text-[14px]">Subscribe</button>
                </div>
            </div>
        </div>
    )
}

export default EmailSubscription