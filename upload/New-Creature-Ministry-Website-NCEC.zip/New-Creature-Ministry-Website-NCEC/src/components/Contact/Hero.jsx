// import React from 'react'

const Hero = () => {
    return (
        <div className="max-w-7xl mx-auto text-center p-30 mt-5 bg-[#F0F3FF]">
            <h1 className="text-blue font-bold text-[48px]">We're Here to Connect</h1>
            <p className="text-[18px] text-offwhite max-w-[667.68px] mx-auto">

                Whether you have a question about our programs, need prayer, or simply want
                to learn more about our community, we look forward to hearing from you.
            </p>
        </div>
    )
}

export default Hero