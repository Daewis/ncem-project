// import React from 'react'
import LocationIcon from '../../assets/Location_Icon.png'
import PhoneIcon from '../../assets/Phone_Icon.png'
import EmailIcon from '../../assets/Email_Icon.png'
import PrayingHand from '../../assets/praying_hand.png'

const ContactForm = () => {
    return (


        <form>
            <div className="max-w-7xl mx-auto bg-[#F0F3FF] px-6 pb-20" >
                {/* Contact form container */}
                <div className="flex justify-between flex-col md:flex-row">
                    {/* Contact Info Card Left side */}
                    <div className="bg-white space-y-5">
                        <div className="border border-offwhite w-[499.33px] p-5 flex justify-start items-start gap-3">
                            <div className='p-4 rounded-[10px] bg-[#F0F3FF]'>
                                <img className='' src={LocationIcon} alt="" />
                            </div>

                            <div>
                                <h2 className="text-blue font-semibold text-[24px]">Office Address</h2>
                                <p>
                                    1234 Divine Light Way
                                    <br />
                                    Suite 100
                                    <br />
                                    Sanctuary City, ST 12345
                                </p>
                            </div>
                        </div>
                        <div className="border border-offwhite p-5 flex justify-start items-start gap-3">
                            <div className='p-4 rounded-[10px] bg-[#F0F3FF]'>
                                <img src={PhoneIcon} alt="" />
                            </div>

                            <div>
                                <h2 className="text-blue font-semibold text-[24px]">Phone</h2>
                                <p className="text-[16px]">
                                    +2348101648772

                                </p>
                                <p className="text-[12px]">
                                    Mon-Fri, 9am - 5pm
                                </p>
                            </div>
                        </div>
                        <div className="border border-offwhite p-5 flex justify-start items-start gap-3">
                            <div className='p-4 rounded-[10px] bg-[#F0F3FF]'>
                                <img src={EmailIcon} alt="" />
                            </div>

                            <div>
                                <h2 className="text-blue font-semibold text-[24px]">Email</h2>
                                <p>
                                    Ncec@gmail.com
                                </p>
                            </div>
                        </div>

                    </div>

                    {/* Contact Info Card right side */}
                    <div className="border border-offwhite pt-10 pb-30 px-10 bg-white relative rounded-[5px]">
                        <h2 className="font-semibold text-[30px] text-blue mb-5">
                            Send a Message
                        </h2>
                        <div className="flex justify-between gap-5">
                            <div className="flex flex-col gap-2">
                                <label htmlFor="name" className="font-semibold text-[14px] text-offwhite">Name</label>
                                <input className="border border-offwhite pl-3 pr-15 py-3" type="text" id='name' name="name" placeholder="Enter your name" />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="font-semibold text-[14px] text-offwhite">Email</label>
                                <input className="border border-offwhite pl-3 pr-15 py-3" type="email" id="email" name="email" placeholder="Enter your email" />
                            </div>
                        </div>
                        <div className="flex flex-col mt-5">
                            <label className="mb-2 text-[14px] font-semibold text-offwhite" htmlFor="message">Message</label>
                            <textarea className="border border-offwhite pt-2 pb-15 pl-3" name="message" id="message" placeholder="Enter your message"></textarea>
                        </div>
                        <button className="absolute right-7 bottom-15 bg-blue text-white font-semibold text-[14px] px-4 py-2 rounded-2xl cursor-pointer">Send Message</button>

                    </div>






                </div>

            </div>
            <div className='max-w-7xl mx-auto'>
                <img className='w-full  bg-cover bg-center' src={PrayingHand} alt="" />
            </div>

        </form>



    )
}

export default ContactForm