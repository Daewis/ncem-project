// import React from 'react'
import Logo from '../../assets/New Creature Evangelical Ministry Logo.png'
const Footer = () => {
    return (
        <div className="footer bg-[#232A3A] flex justify-around items-start  max-w-7xl mx-auto h-144 ">
            <div className="w-71 mt-50">
                <div className='flex justify-start items-center gap-6 '>
                    <img src={Logo} alt="" />
                    <h2 className="font-bold text-[24px]">NCEM</h2>
                </div>
                <p className="text-[16px]">
                    Illuminating paths, fostering
                    connections, and serving with
                    purpose.
                </p>
            </div>
            <ul className="space-y-4 mt-50">
                <li className="font-semibold text-[14px]">Navigation</li>
                <li>Home</li>
                <li >About</li>
                <li>Programs</li>
                <li>Events</li>
            </ul>
            <ul className="space-y-4 mt-50">
                <li className="font-semibold text-[14px]   ">Connect</li>
                <li>Location </li>
                <li>Resources</li>
                <li>Contact</li>

            </ul>
            <ul className="space-y-4 mt-50">
                <li className="font-semibold text-[14px]  ">Legal</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
            </ul>
        </div>
    )
}

export default Footer