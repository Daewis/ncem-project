// import React from 'react'
import RightHandArrow from '../../assets/Icon_right_arrow.png'
import CardImageOne from '../../assets/card_image_one.png'
import CardImageTwo from '../../assets/card_image_two.png'
import CardImageThree from '../../assets/card_image_three.png'
import ClockIcon from '../../assets/Clock_Icon.png'
import LocationIcon from '../../assets/Location_Icon.png'

const Upcoming_Events = () => {
    return (
        <div className='events py-10 px-3 max-w-304 mx-auto'>

            {/* Upcoming Event Heading */}

            <div className="flex items-end justify-between relative p-10">
                <div>
                    <h4 className="uppercase text-yellow text-[14px] mb-2">gatherings</h4>
                    <h2 className='text-[32px] text-blue font-semibold capitalize'>upcoming events</h2>
                </div>
                <button className="group flex items-center justify-center gap-3 px-3 py-2 bg-blue-100 ">
                    <p>view all events</p>
                    <img src={RightHandArrow} alt="Right_Hand_Arrow" />
                </button>

            </div>
            {/* Upcoming Event Cards */}
            <div className='flex gap-10 '>
                <div>
                    <div className='relative  '>
                        <img src={CardImageOne} className='rounded-tr-[10px] rounded-tl-[10px] w-full' alt="" />
                        <div className='absolute top-2 left-2 bg-amber-400 px-5 py-1 rounded-[15px]'>
                            <p className='font-semibold'>Oct 15</p>
                        </div>
                    </div>
                    <div className='space-y-5 p-5 bg-blue-50 rounded-br-[10px] rounded-bl-[10px] '>
                        <div className='flex gap-4'>
                            <div className='flex gap-2'>
                                <img src={ClockIcon} alt="" />
                                <p className='text-[12px]'> 6:00PM</p>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <img src={LocationIcon} alt="" />
                                <p className='text-[12px] whitespace-nowrap'>
                                    Main Auditorium
                                </p>
                            </div>
                        </div>
                        <h3 className='text-[20px] text-blue-900 font-bold'
                        >Ministers Conference</h3>
                        <p className='text-[16px]'>
                            A night of powerful worship, transformative teachings, and community for young adults
                            seeking deeper connection.
                        </p>
                        <div className='group flex justify-between items-center'>
                            <p>View Event Details</p>
                            <img className='w-4 h-4' src={RightHandArrow} alt="" />
                        </div>
                    </div>


                </div>
                <div>
                    <div className='relative  '>
                        <img src={CardImageTwo} className='rounded-tr-[10px] rounded-tl-[10px] w-full h-[232px]' alt="" />
                        <div className='absolute top-2 left-2 bg-amber-400 px-5 py-1 rounded-[15px]'>
                            <p className='font-semibold'>Oct22</p>
                        </div>
                    </div>
                    <div className='space-y-5 p-5 bg-blue-50 rounded-br-[10px] rounded-bl-[10px] '>
                        <div className='flex gap-4'>
                            <div className='flex gap-2'>
                                <img src={ClockIcon} alt="" />
                                <p className='text-[12px]'> 6:00PM</p>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <img src={LocationIcon} alt="" />
                                <p className='text-[12px] whitespace-nowrap'>
                                    Conference Hall
                                </p>
                            </div>
                        </div>
                        <h3 className='text-[20px] text-blue-900 font-bold'
                        >Youth Conference</h3>
                        <p className='text-[16px]'>
                            Equipping current and emerging leaders
                            with principles for impactful ministry and
                            marketplace dominance.
                        </p>
                        <div className='group flex justify-between items-center'>
                            <p>View Event Details</p>
                            <img className='w-4 h-4' src={RightHandArrow} alt="" />
                        </div>
                    </div>


                </div>
                <div className=''>
                    <div className='relative  '>
                        <img src={CardImageThree} className='rounded-tr-[10px] rounded-tl-[10px] w-full h-[232px]' alt="" />
                        <div className='absolute top-2 left-2 bg-amber-400 px-5 py-1 rounded-[15px]'>
                            <p className='font-semibold'>Nov 5</p>
                        </div>
                    </div>
                    <div className='space-y-5 p-5 bg-blue-50 rounded-br-[10px] rounded-bl-[10px] '>
                        <div className='flex gap-4'>
                            <div className='flex gap-2'>
                                <img src={ClockIcon} alt="" />
                                <p className='text-[12px]'> 6:00PM</p>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <img src={LocationIcon} alt="" />
                                <p className='text-[12px] whitespace-nowrap'>
                                    Main Sanctaury
                                </p>
                            </div>
                        </div>
                        <h3 className='text-[20px] text-blue-900 font-bold'
                        >Thanksgiving Service</h3>
                        <p className='text-[16px]'>
                            Join us for a special combined service as
                            we gather to celebrate God's faithfulness
                            throughout the year.
                        </p>
                        <div className='group flex justify-between items-center'>
                            <p>View Event Details</p>
                            <img className='w-4 h-4' src={RightHandArrow} alt="" />
                        </div>
                    </div>


                </div>

            </div>
        </div >
    )
}

export default Upcoming_Events