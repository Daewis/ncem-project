// import React from 'react'
import backgroundImage from '../../assets/Gradient.png'

const Hero = () => {
    return (
        <div className='h-screen w-full bg-cover bg-center flex flex-col items-center justify-center md:pt-1 pt-1 px-7 md:px-0 space-y-7 text-center text-white max-w-7xl mx-auto'
            style={{ backgroundImage: `url(${backgroundImage})` }}>
            <h1 className='md:text-home-heading-large text-home-heading-small relative font-bold max-w-3xl mx-auto'>if any man is in christ is a new creature</h1>
            <p className='max-w-2xl mx-auto'>

                Welcome to a community of faith, hope, and      purpose. We are dedicated to sharing
                the transformative power of the Gospel in a modern world, building strong
                foundations for generations to come.

            </p>
            <div className='hero flex gap-5'>
                <button className='bg-yellow px-6 py-3 text-black rounded-[15px] cursor-pointer'>Find a church</button>
                <button className=' border-yellow border-2 py-3 px-5 rounded-[15px] cursor-pointer'>Explore Events</button>
            </div>

        </div >
    )
}

export default Hero