
import { Link } from 'react-router-dom';
import Logo from '../../assets/New Creature Evangelical Ministry Logo.png'

const Navbar = () => {
    return (
        <div className='flex items-center justify-between px-4 sm:px-10 md:px-10 lg:px-10 py-4 max-w-7xl mx-auto   border-b border-offwhite shadow-offwhite' >
            {/* Navbar Logo */}
            <div className='flex items-center justify-between  gap-2'>
                <Link to='/'>
                    <img src={Logo} alt="New Creature Evangelical Ministry Logo" />
                </Link>

                <h1 className='w-40 text-blue font-bold text-[24px]'>NCEM</h1>
            </div>

            {/* Navbar content */}
            <div className='nav-item flex items-center justify-between gap-5 font-semibold  '>
                <Link to='/'>Home</Link>
                <Link to='/about'>About</Link>
                <Link to='/programs'>programs</Link>
                <Link>Events</Link>
                <Link>Locations</Link>
                <Link>Resouces</Link>
                <Link to='/contact'>Contact</Link>
            </div>

            {/* Navbar Button */}
            <button className='bg-yellow-300 px-5 py-2 rounded-md font-semibold cursor-pointer'>
                <Link to='/givenow'>  Give now</Link>
            </button>
        </div>
    );
};

export default Navbar;