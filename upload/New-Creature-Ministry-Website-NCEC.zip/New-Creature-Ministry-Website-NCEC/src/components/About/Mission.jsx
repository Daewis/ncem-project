// import React from 'react'
import EyeIcon from '../../assets/Icon_eye.png'
import JetIcon from '../../assets/JetIcon.png'

const Mission = () => {
    return (
        <div className='flex justify-center items-center max-w-7xl mx-auto bg-[#E7EEFE] py-20 px-5 gap-7'>
            <div className='max-w-146 p-10 bg-white space-y-5 rounded-2xl'>

                <div className='bg-[#1E3A8A1A] p-5 w-16 rounded-[10px]'>
                    <img src={EyeIcon} alt="" />
                </div>
                <h2 className='text-blue font-semibold text-[24px]'>Our Vision</h2>
                <p>
                    To be a beacon of undeniable hope and profound
                    spiritual clarity, illuminating the intersection of modern
                    life and timeless faith for all generations.
                </p>
            </div>
            <div className='max-w-146 p-10 bg-white space-y-5 rounded-2xl'>
                <div className='bg-[#FFDF9F4D] p-5 w-16 rounded-[10px]'>
                    <img src={JetIcon} alt="" />
                </div>

                <h2 className='text-blue font-semibold text-[24px]'>Our Mission</h2>
                <p>

                    We equip individuals to navigate life with purpose and
                    grace by providing authentic community, practical
                    spiritual resources, and opportunities for selfless
                    service.

                </p>

            </div>
        </div >
    )
}

export default Mission