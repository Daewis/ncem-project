import { Route, Routes } from "react-router-dom"
import Navbar from "./components/Home/Navbar"
import About from "./pages/About"
import Home from "./pages/Home"
import Contact from "./pages/Contact"
import Givenow from "./pages/Givenow"

// import React from 'react'
const App = () => {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/givenow" element={<Givenow />} />

      </Routes>





    </div>
  )
}

export default App